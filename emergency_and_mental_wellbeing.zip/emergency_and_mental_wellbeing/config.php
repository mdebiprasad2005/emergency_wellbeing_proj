<?php
// config.php
return [
    'openai_api_key' => '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', // Replace with your actual API key
];
