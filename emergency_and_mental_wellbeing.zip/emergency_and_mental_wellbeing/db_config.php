<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'emergency_db'; // Replace with your database name
$port = 3306;

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
