<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot - Emergency and Mental Wellbeing</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('images/pngtree-mental-health-word-concepts-pink-banner-infographic-mental-wellbeing-vector-png-image_46047022.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #FF007F;
            padding: 10px 20px;
            color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header .logo {
            display: flex;
            align-items: center;
        }

        .header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
        }

        .header h1 {
            margin: 0;
            font-size: 20px;
        }

        .header nav {
            display: flex;
            gap: 15px;
        }

        .header nav a, .logout-button {
            text-decoration: none;
            color: white;
            background-color: #FF007F;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }

        .logout-button:hover, .header nav a:hover {
            background-color: #ff569f;
        }

        .chat-container {
            margin: 20px auto;
            width: 400px;
            background: rgba(255, 255, 255, 0.7); /* Semi-transparent glass effect */
            backdrop-filter: blur(10px);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .chat-header {
            background-color: #FF007F;
            padding: 15px;
            color: white;
            text-align: center;
            font-size: 18px;
        }

        .chat-messages {
            padding: 15px;
            flex: 1;
            overflow-y: auto;
            max-height: 300px;
            font-size: 16px;
        }

        .chat-messages p {
            margin: 5px 0;
            word-wrap: break-word;
        }

        .chat-messages img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            vertical-align: middle;
            margin-right: 5px;
        }

        .chat-input {
            display: flex;
            padding: 10px;
            background-color: rgba(255, 255, 255, 0.6);
            border-top: 1px solid #ddd;
        }

        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }

        .chat-input button {
            background-color: #FF007F;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        .chat-input button:hover {
            background-color: #ff569f;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="images/logo.png" alt="Logo">
            <h1>Welcome <?php echo htmlspecialchars($_SESSION['user_name']); ?> to the Mental Health Care System</h1>
        </div>
        <nav>
            <a href="home.php">Home</a>
            <a href="profile.php">My Profile</a>
            <a href="grievance.php">Grievance</a>
            <a href="help.php">Help</a>
            <a href="logout.php" class="logout-button">Logout</a>
        </nav>
    </header>
    <div class="chat-container">
        <div class="chat-header">
            <strong>Chatbot Support</strong>
        </div>
        <div class="chat-messages" id="chatMessages"></div>
        <div class="chat-input">
            <input type="text" id="userInput" placeholder="Type your message here..." />
            <button onclick="sendMessage()">Send</button>
        </div>
    </div>
    <script>
        const responses = {
         
    "hi": "Hi there! I'm here to help. 😊",
    "hello": "Hello! How can I assist you today?",
    "help": "Here are some questions you can ask:\n- What is mental health?\n- How to overcome stress?\n- Tips for self-care.",
    "what is mental health": "Mental health includes emotional, psychological, and social well-being. It affects how we think, feel, and act.",
    "how to overcome stress": "Try relaxation techniques such as deep breathing, meditation, or engaging in hobbies you enjoy. Exercise and talking to someone can also help.",
    "tips for self-care": "Self-care includes eating a balanced diet, exercising regularly, getting enough sleep, and taking time to relax.",
    "what is anxiety": "Anxiety is a feeling of fear or worry about a situation. It's normal but can become problematic if it interferes with daily life.",
    "how to manage anxiety": "Practice deep breathing, mindfulness, and progressive muscle relaxation. Speak to a mental health professional if needed.",
    "what is depression": "Depression is a mental health condition marked by persistent sadness, loss of interest, and fatigue.",
    "how to handle depression": "Seek professional help, stay active, and reach out to friends and family for support.",
    "what is mindfulness": "Mindfulness is being present in the moment, fully aware of your thoughts and feelings without judgment.",
    "how to practice mindfulness": "Start with simple exercises like focusing on your breath or paying attention to your surroundings.",
    "what is emotional intelligence": "Emotional intelligence is the ability to understand, use, and manage your emotions positively.",
    "how to improve emotional intelligence": "Practice empathy, self-awareness, and active listening. Reflect on your emotions regularly.",
    "what is resilience": "Resilience is the ability to recover quickly from setbacks and adapt to challenging circumstances.",
    "how to build resilience": "Maintain strong relationships, develop a positive mindset, and practice problem-solving skills.",
    "how to deal with loneliness": "Engage in activities you enjoy, join social groups, and reach out to friends and family.",
    "importance of sleep": "Sleep is crucial for mental and physical health. It helps with emotional regulation and cognitive functioning.",
    "how to get better sleep": "Maintain a consistent sleep schedule, create a relaxing bedtime routine, and avoid screens before bed.",
    "what is self-esteem": "Self-esteem is the way you value and perceive yourself. It plays a key role in mental well-being.",
    "how to boost self-esteem": "Focus on your strengths, set realistic goals, and avoid negative self-talk.",
    "what is burnout": "Burnout is physical, emotional, and mental exhaustion caused by prolonged stress or overwork.",
    "how to recover from burnout": "Take breaks, prioritize self-care, and seek support from loved ones or professionals.",
    "what is work life balance": "Work-life balance is the ability to prioritize work responsibilities and personal life effectively.",
    "how to improve work-life balance": "Set boundaries, delegate tasks, and ensure you make time for relaxation and hobbies.",
    "importance of hobbies": "Hobbies can help reduce stress, improve creativity, and provide a sense of accomplishment.",
    "what is cognitive-behavioral therapy": "CBT is a form of therapy that helps people change negative thought patterns to improve their mental health.",
    "how to stay motivated": "Set clear goals, celebrate small wins, and remind yourself of your purpose.",
    "how to handle criticism": "Take feedback as an opportunity to learn. Stay calm and focus on constructive suggestions.",
    "importance of gratitude": "Gratitude helps improve mental health by shifting focus to positive aspects of life.",
    "how to practice gratitude": "Write a gratitude journal, express thanks to others, and reflect on things you're grateful for daily.",
    "what is social anxiety": "Social anxiety is the fear of being judged or embarrassed in social situations.",
    "how to overcome social anxiety": "Practice exposure, use positive self-talk, and consider therapy for support.",
    "importance of exercise": "Exercise boosts mood, reduces stress, and improves overall mental health.",
    "how to stay physically active": "Incorporate activities like walking, yoga, or sports into your daily routine.",
    "what is meditation": "Meditation is a practice of focusing your mind to achieve mental clarity and emotional calmness.",
    "how to start meditating": "Begin with a few minutes a day, find a quiet place, and focus on your breathing or a mantra.",
    "what is PTSD": "Post-Traumatic Stress Disorder is a mental health condition triggered by experiencing or witnessing a traumatic event.",
    "how to cope with PTSD": "Seek professional help, connect with support groups, and practice grounding techniques.",
    "what is bipolar disorder": "Bipolar disorder is a mental health condition characterized by extreme mood swings, including manic and depressive episodes.",
    "how to support someone with bipolar disorder": "Encourage treatment, be patient, and educate yourself about the condition.",
    "importance of support systems": "Having a strong support system can improve mental resilience and provide emotional security.",
    "how to handle anger": "Take deep breaths, step away from the situation, and express your feelings calmly.",
    "what is positive psychology": "Positive psychology focuses on strengths, virtues, and factors that lead to a fulfilling life.",
    "how to set goals": "Make goals specific, measurable, achievable, relevant, and time-bound (SMART).",
    "importance of communication": "Effective communication helps build relationships, resolve conflicts, and express emotions.",
    "how to improve communication skills": "Practice active listening, be clear and concise, and use open body language.",
    "how to handle rejection": "Focus on self-compassion, view rejection as a learning experience, and move forward with confidence.",
    "how to overcome fear": "Face fears gradually, reframe negative thoughts, and seek support if needed.",
    "how to find a therapist": "Search online directories, ask for recommendations, or contact your local mental health services.",
    "what is trauma": "Trauma is a deeply distressing or disturbing experience that can impact mental health.",
    "how to heal from trauma": "Seek professional help, practice self-care, and connect with supportive people.",
    "importance of laughter": "Laughter reduces stress, improves mood, and strengthens social bonds.",
    "how to stay optimistic": "Focus on positive outcomes, surround yourself with positive people, and practice gratitude.",
    "importance of self-reflection": "Self-reflection helps you understand your thoughts, emotions, and actions, leading to personal growth.",
    "how to break bad habits": "Identify triggers, replace negative behaviors with positive ones, and seek support.",
    "what is compassion fatigue": "Compassion fatigue is emotional exhaustion from caring for others, often affecting caregivers.",
    "how to cope with compassion fatigue": "Set boundaries, practice self-care, and seek professional support if needed.",
    "importance of boundaries": "Setting boundaries helps protect your mental health and maintain healthy relationships.",
    "how to say no": "Be assertive, use a polite tone, and explain your reasons if necessary.",
    "default": "I'm sorry, I didn't understand that. Could you please rephrase or ask something else?"
};

       

        function sendMessage() {
            const userInput = document.getElementById('userInput').value.trim().toLowerCase();
            const chatMessages = document.getElementById('chatMessages');

            if (userInput !== "") {
                const userMessage = document.createElement('p');
                userMessage.innerHTML = `<strong>You:</strong> ${userInput}`;
                chatMessages.appendChild(userMessage);

                document.getElementById('userInput').value = '';

                setTimeout(() => {
                    const botResponse = responses[userInput] || responses["default"];
                    const botMessage = document.createElement('p');
                    botMessage.innerHTML = `<img src="images/ec6c85439ea5235614deaaa2f12f4335.jpg" alt="Bot"> <strong>Bot:</strong> ${botResponse}`;
                    chatMessages.appendChild(botMessage);

                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }, 500);
            }
        }
    </script>
</body>
</html>
