<?php
// Include Composer's autoload
require __DIR__ . '/vendor/autoload.php';

// Include configuration for API key
require __DIR__ . '/config/config.php';

// Use OpenAI Client
use OpenAI\Client;

// Initialize OpenAI client
$openai = new Client([
    'apiKey' => $config['openai_api_key'],
]);

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $message = $input['message'] ?? 'No message provided';

    try {
        // Get response from OpenAI API
        $response = $openai->completions()->create([
            'model' => 'text-davinci-003',
            'prompt' => $message,
            'max_tokens' => 100,
            'temperature' => 0.7,
        ]);

        echo json_encode(['response' => $response['choices'][0]['text']]);
    } catch (Exception $e) {
        echo json_encode(['response' => 'Error: ' . $e->getMessage()]);
    }
}
?>
