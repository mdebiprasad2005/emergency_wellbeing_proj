<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #FF007F;
            padding: 10px 20px;
            color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header .logo {
            display: flex;
            align-items: center;
        }

        .header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
        }

        .header h1 {
            margin: 0;
            font-size: 20px;
        }

        .header nav {
            display: flex;
            gap: 15px;
        }

        .header nav a, .logout-button {
            text-decoration: none;
            color: white;
            background-color: #FF007F;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }

        .logout-button:hover, .header nav a:hover {
            background-color: #ff569f;
        }

        .main-content {
            position: relative;
            background: url('images/pngtree-mental-health-word-concepts-pink-banner-infographic-mental-wellbeing-vector-png-image_46047022.jpg') no-repeat center center;
            background-size: cover;
            min-height: calc(100vh - 70px); /* Full height minus header */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .content-box {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            max-width: 600px;
        }

        .content-box h2 {
            color: #FF007F;
            margin-bottom: 20px;
        }

        .module-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
        }

        .module-buttons a {
            display: inline-block;
            text-decoration: none;
            color: white;
            background-color: #FF007F;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
        }

        .module-buttons a:hover {
            background-color: #ff569f;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="images/logo.png" alt="Logo">
            <h1>Welcome  <?php echo htmlspecialchars($_SESSION['user_name']); ?> to the Mental Health Care System</h1>
        </div>
        <nav>
            <a href="home.php">Home</a>
            <a href="profile.php">My Profile</a>
            <a href="grievance.php">Grievance</a>
            <a href="help.php">Help</a>
            <a href="logout.php" class="logout-button">Logout</a>
        </nav>
    </header>
    <div class="main-content">
        <div class="content-box">
            <h2> Strong Mental Health Care Builds
			Stronger & Healthier Communities !</h2>
            <p>Unfold the journey of mindful Self care and Mental peace !!</p>
            <div class="module-buttons">
                <a href="sos.php">SOS</a>
                <a href="emergency_contact.php">Emergency Contact</a>
                <a href="mental_health_qa.php">Mental Health Q&A</a>
                <a href="chatbot.php">Chatbot</a>
                <a href="video_recommendation.php">Video Recommendation</a>
                <a href="mood_tracker.php">Mood Tracker</a>
                <a href="news_api.php">News API</a>
                <a href="task_management.php">Task Management</a>
            </div>
        </div>
    </div>
</body>
</html>
