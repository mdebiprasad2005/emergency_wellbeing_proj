<?php
require 'db_config.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    if (empty($email)) {
        echo "<script>alert('Please enter your email.');</script>";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Email found! You can reset your password.');</script>";
            header("Location: reset_password.php?email=" . urlencode($email));
            exit();
        } else {
            echo "<script>alert('No account found with this email.');</script>";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('images/78088725-abstract-molecules-medical-background-pink-background-illustration.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .form-container {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.2); /* Transparent white */
            backdrop-filter: blur(10px); /* Frosted glass effect */
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2); /* Soft shadow */
            border: 1px solid rgba(255, 255, 255, 0.3); /* Semi-transparent border */
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #FF007F;
            font-size: 24px;
        }

        input[type="email"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 10px 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button {
            width: 48%;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            border: none;
        }

        .submit-button {
            background-color: #FF007F;
            color: white;
        }

        .submit-button:hover {
            background-color: #e60073;
        }

        .cancel-button {
            background-color: white;
            color: #FF007F;
            border: 1px solid #FF007F;
        }

        .cancel-button:hover {
            background-color: #f8f8f8;
        }

        button:focus {
            outline: none;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Forgot Password</h2>
        <form method="POST" action="">
            <input type="email" name="email" placeholder="Enter your registered email" required>
            <div class="button-container">
                <button type="submit" class="submit-button">Submit</button>
                <button type="button" class="cancel-button" onclick="window.location.href='login.php';">Cancel</button>
            </div>
        </form>
    </div>
</body>
</html>
