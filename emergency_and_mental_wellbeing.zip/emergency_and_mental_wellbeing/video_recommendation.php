<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Recommendations</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('images/pngtree-mental-health-word-concepts-pink-banner-infographic-mental-wellbeing-vector-png-image_46047022.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #FF007F;
            padding: 10px 20px;
            color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header .logo {
            display: flex;
            align-items: center;
        }

        .header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
        }

        .header h1 {
            margin: 0;
            font-size: 20px;
        }

        .header nav {
            display: flex;
            gap: 15px;
        }

        .header nav a, .logout-button {
            text-decoration: none;
            color: white;
            background-color: #FF007F;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }

        .logout-button:hover, .header nav a:hover {
            background-color: #ff569f;
        }

        .content {
            padding: 20px;
            max-width: 800px;
            margin: 30px auto;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        iframe {
            width: 100%;
            height: 315px;
            margin-bottom: 20px;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="images/logo.png" alt="Logo">
            <h1>Welcome <?php echo htmlspecialchars($_SESSION['user_name']); ?> to Video Recommendations</h1>
        </div>
        <nav>
            <a href="home.php">Home</a>
            <a href="profile.php">My Profile</a>
            <a href="grievance.php">Grievance</a>
            <a href="help.php">Help</a>
            <a href="logout.php" class="logout-button">Logout</a>
        </nav>
    </header>
    <div class="content">
        <h2>Recommended Videos</h2>
        <p>Here are some curated videos to help manage stress, anxiety, and improve your overall well-being:</p>
        <!-- Embed YouTube videos -->
        <iframe src="https://www.youtube.com/embed/0fL-pn80s-c" allowfullscreen></iframe>
        <iframe src="https://www.youtube.com/embed/aEqlQvczMJQ" allowfullscreen></iframe>
        <iframe src="https://www.youtube.com/embed/2rXp9-b4sWQ" allowfullscreen></iframe>
        <iframe src="https://www.youtube.com/embed/6xKRSQXa2X4" allowfullscreen></iframe>
    </div>
</body>
</html>
